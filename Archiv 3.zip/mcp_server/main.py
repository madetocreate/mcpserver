from __future__ import annotations

import signal
import sys

from .server import mcp


def main() -> None:
    try:
        mcp.run(transport="streamable-http")
    except KeyboardInterrupt:
        print("\nServer shutdown requested...")
        sys.exit(0)


if __name__ == "__main__":
    main()
